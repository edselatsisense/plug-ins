export const defaultConfig = [
	{
		groupName: 'Admins',
		wScript: `

			widget.on('processresult',function(w,e){
		
				e.result.plotOptions.series.dataLabels.style.color = 'red';
				e.result.plotOptions.series.dataLabels.style.fontSize = '10px';
				e.result.plotOptions.series.dataLabels.style.fontWeight = 'bold';
				e.result.plotOptions.series.dataLabels.allowOverlap = true;
		
			})
		`
	},
	
	{
		groupName: '',
		wScript: ''
	},
]