/*************************************************
// Widget Script Applier
// Last Modified: 11152021
// Created By: Edsel Villadoz
// Description: This Plug-In will apply a script to all widgets in a dashboard based on user group;
**************************************************/
import { defaultConfig } from './config'; //locate config file and import wScrpt variable

prism.run([() => { //enter prism object
		prism.on("dashboardloaded", (el, args) => {
			prism.activeDashboard.widgets.$$widgets.forEach(widget => {			
				defaultConfig.forEach((config) => { //Loop through each config
					prism.user.groupsName.forEach((prismGroup) => { //Loop through each user group
						if(config.groupName === prismGroup.name) { //Match config to a user group
							widget.script = config.wScript; // grab wScript and place into widget script
							widget.refresh(); //once widget script is loaded refresh the widget to apply changes
						}
					});
				});
        	});
		});	
 	},
]);